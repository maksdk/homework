function privateMethod() {
                document.write("Закрытый метод");
            }
            var privateMethod = function () {
                document.write("Закрытый метод");
            };