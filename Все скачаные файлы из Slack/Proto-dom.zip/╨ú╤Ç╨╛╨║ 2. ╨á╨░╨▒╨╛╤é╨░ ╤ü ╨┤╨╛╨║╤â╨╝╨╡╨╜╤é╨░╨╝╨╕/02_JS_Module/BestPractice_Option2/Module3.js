﻿
(function () {
    var message = "Hello from module3";
    alert(message);
})()
